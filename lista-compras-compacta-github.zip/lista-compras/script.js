'use strict';

const STORAGE_KEY = 'lista-compras-v1';
const form = document.querySelector('#product-form');
const list = document.querySelector('#shopping-list');
const counter = document.querySelector('#counter');
const emptyState = document.querySelector('#empty-state');
const clearBoughtButton = document.querySelector('#clear-bought');

function loadItems() {
  try {
    const stored = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
    return Array.isArray(stored) ? stored.filter(item =>
      item && typeof item.id === 'string' && typeof item.name === 'string' &&
      typeof item.quantity === 'number' && typeof item.unit === 'string'
    ) : [];
  } catch {
    return [];
  }
}

let items = loadItems();

function saveItems() {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(items));
  } catch {
    alert('Não foi possível guardar a lista neste navegador.');
  }
}

function render() {
  list.replaceChildren();
  for (const item of items) {
    const li = document.createElement('li');
    li.className = item.bought ? 'bought' : '';

    const checkbox = document.createElement('input');
    checkbox.type = 'checkbox';
    checkbox.checked = Boolean(item.bought);
    checkbox.setAttribute('aria-label', `Marcar ${item.name} como comprado`);
    checkbox.addEventListener('change', () => {
      item.bought = checkbox.checked;
      saveItems();
      render();
    });

    const name = document.createElement('span');
    name.className = 'name';
    const title = document.createElement('strong');
    title.textContent = item.name;
    const detail = document.createElement('small');
    detail.textContent = `${item.quantity} ${item.unit}`;
    name.append(title, detail);

    const remove = document.createElement('button');
    remove.type = 'button';
    remove.className = 'delete';
    remove.textContent = '×';
    remove.setAttribute('aria-label', `Eliminar ${item.name}`);
    remove.addEventListener('click', () => {
      items = items.filter(current => current.id !== item.id);
      saveItems();
      render();
    });

    li.append(checkbox, name, remove);
    list.append(li);
  }
  const pending = items.filter(item => !item.bought).length;
  counter.textContent = `${pending} por comprar`;
  emptyState.hidden = items.length > 0;
  clearBoughtButton.hidden = !items.some(item => item.bought);
}

form.addEventListener('submit', event => {
  event.preventDefault();
  const name = form.elements.product.value.trim();
  const quantity = Number(form.elements.quantity.value);
  const unit = form.elements.unit.value;
  if (!name || !Number.isFinite(quantity) || quantity <= 0 || quantity > 99999) return;
  items.push({ id: crypto.randomUUID(), name, quantity, unit, bought: false });
  saveItems();
  render();
  form.reset();
  form.elements.product.focus();
});

clearBoughtButton.addEventListener('click', () => {
  items = items.filter(item => !item.bought);
  saveItems();
  render();
});

render();
