# Compras — lista compacta

Aplicação de lista de compras, otimizada para telemóveis, com interface minimalista e sem dependências.

## Funcionalidades
- Adicionar produto, quantidade e unidade numa única linha
- Marcar como comprado
- Eliminar produtos individualmente ou limpar os comprados
- Guardar automaticamente os dados no `localStorage` do navegador

## Utilização
Abre `index.html` num navegador.

## Publicar no GitHub Pages
1. Cria um repositório no GitHub.
2. Carrega os ficheiros deste projeto na raiz do repositório.
3. Vai a **Settings → Pages**.
4. Seleciona **Deploy from a branch**, branch `main`, pasta `/ (root)`.

Os dados são guardados apenas no navegador/dispositivo onde a lista é utilizada.
